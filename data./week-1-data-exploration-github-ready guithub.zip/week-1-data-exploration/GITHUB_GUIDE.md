# GitHub Repository Guide — What Goes Where

## 1. data/
Put the original dataset here.
- `Sample - Superstore.csv`
- Do not edit the original file manually.
- This is the input for your analysis.

## 2. notebooks/
Put your Jupyter Notebook here.
- `Week_1_Data_Exploration.ipynb`
- This is where you show your actual analysis.
- Run every cell before submitting so outputs and charts are visible.
- Add short Markdown observations below important outputs.

## 3. src/
Put reusable Python scripts here.
- `data_exploration.py`
- This contains the same core analysis in a reusable `.py` format.

## 4. visualizations/
Put important charts here.
- `monthly_sales.png`
- `category_sales.png`
- `region_sales.png`
- `profit_subcategory.png`

## 5. reports/
Put your final internship report here.
- `Week_1_Data_Exploration_and_Problem_Definition.docx`
- This is the formal document submission.

## 6. README.md
This is the first page visitors see on GitHub.
It explains:
- project objective
- dataset
- problem statement
- questions
- hypotheses
- tools
- repository structure
- how to run the project

## 7. requirements.txt
This lists Python packages needed to run the project.

## 8. .gitignore
This prevents temporary Python/Jupyter files from being uploaded.

# What You Should Do

### Step 1 — Open the notebook
Open:
`notebooks/Week_1_Data_Exploration.ipynb`

Run all cells.

### Step 2 — Read the outputs
Check:
- shape
- columns
- data types
- missing values
- duplicates
- summary statistics
- sales
- profit
- category results
- region results
- monthly trend

### Step 3 — Add observations
After important results, write 1–3 sentences explaining what the result means for the business.

### Step 4 — Check the DOCX
Open the report in `reports/` and verify your name, formatting and figures.

### Step 5 — Upload the whole folder to GitHub
Do not upload only the README. Upload the complete repository structure.

# Git Commands

```bash
git init
git add .
git commit -m "Week 1: Data Exploration and Problem Definition"
git branch -M main
git remote add origin YOUR_REPOSITORY_URL
git push -u origin main
```

# Final Check

Before submitting, make sure GitHub contains:

- [x] README.md
- [x] Dataset
- [x] Jupyter Notebook
- [x] Python script
- [x] Visualizations
- [x] DOCX report
- [x] requirements.txt
- [x] .gitignore
