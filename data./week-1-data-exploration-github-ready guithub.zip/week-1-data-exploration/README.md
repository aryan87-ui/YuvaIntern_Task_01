# Week 1 — Data Exploration and Problem Definition

## Data Analytics Internship Project

This repository contains my Week 1 Data Analytics project using the Sample Superstore sales dataset.

### Objectives
- Explore the structure and variables of a retail sales dataset.
- Check data quality, missing values and duplicates.
- Perform descriptive statistics and basic EDA.
- Visualize sales and profit patterns.
- Define a business problem, questions and hypotheses.
- Prepare an analysis strategy for future weeks.

## Repository Structure

```text
week-1-data-exploration/
│
├── data/
│   └── Sample - Superstore.csv
│
├── notebooks/
│   └── Week_1_Data_Exploration.ipynb
│
├── reports/
│   └── Week_1_Data_Exploration_and_Problem_Definition.docx
│
├── visualizations/
│   ├── monthly_sales.png
│   ├── category_sales.png
│   ├── region_sales.png
│   └── profit_subcategory.png
│
├── src/
│   └── data_exploration.py
│
├── README.md
├── requirements.txt
└── .gitignore
```

## Main Problem Statement

The business needs to understand the factors associated with sales and profitability across products, categories, regions, customer segments and time.

The analysis will identify areas generating strong revenue, areas generating weak or negative profit, and relationships between discounting, quantity, sales and profit.

## Key Questions
1. How do sales and profit change over time?
2. Which categories and sub-categories generate the most sales and profit?
3. Which products generate high sales but low or negative profit?
4. Does higher discounting appear to be associated with lower profit?
5. Which regions and customer segments contribute most to revenue and profit?

## Hypotheses
- H1: Higher discount levels are associated with lower profit margins.
- H2: Sales and profit differ across product categories and sub-categories.
- H3: High-sales products are not necessarily high-profit products.
- H4: Regional performance differs in revenue and profitability.
- H5: Sales show time-based patterns or seasonality.

## Tools
Python, Pandas, NumPy, Matplotlib, Jupyter Notebook, Git and GitHub.

## How to Run

```bash
pip install -r requirements.txt
jupyter notebook
```

Open `notebooks/Week_1_Data_Exploration.ipynb`.

## Author
Aryan Verma
